<!-- /martina/wp-content/plugins/modal-scroll-img/inc-modal.php
最初は単体でテストする URLも直に開くためのもの -->

<?php
$cat = get_the_category(); //現在のページのカテゴリ―を取得
if(!empty($cat)) {
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

<?php
$cat_id = $cat[0] -> cat_ID; //取得したカテゴリーのIDを取り出す
if(in_array( $cat_id, $scroll_data['cat_ID'])){
// (複数)指定したカテゴリの場合
$upload_dir = wp_upload_dir();
// var_dump($upload_dir);
?>

<style>
.no-padding-right {
  padding-right: 0 !important;
}
</style>

<!-- Modal -->
<div class="modal fade mt-5 pt-5 px-0" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <a href="<?= $scroll_data["url"] ?>">
          <img src="<?= $upload_dir['baseurl'] ."/". $scroll_data["image_path"] ?>" alt="">
        </a>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
<?php }
}?>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {

  // ↑ jQueryの読み込みを待ってから実行
  var myModal = new bootstrap.Modal(
    document.getElementById('exampleModal')
  );

  $('#exampleModal').on('show.bs.modal', function() {
    $('body').addClass('no-padding-right');
  });

  // モーダルを表示 v5
  // myModal.show();


  jQuery(function($) {
    // ↑ この中なら $ が使える
    let notYet = true; // もう出た､出てないの変数｡ 初回は映る
    // ロード時
    modalShow();


    // スクロール時イベント発火
    $(window).on("scroll", function() {
      let y = $(window).scrollTop();
      console.log(y);
      modalShow();
    });


    // ロード時とスクロール時にこの関数を呼び出す
    function modalShow() {
      let y = $(window).scrollTop();
      let top = '<?= $scroll_data["top"] ?>'; // int 700

      console.log(y);
      if (y >= top && notYet) {
        //modalをコードで出す ver4で
        myModal.show();
        notYet = false; // グローバルをfalseを代入
      }
    }
  });
})
</script>
<?php
// 送信用のファイルと受信用のファイルが同じ場合
$info = "";
if(!empty($_POST['image_path']) &&
   !empty($_POST['cat_ID']) &&
   !empty($_POST['top']) &&
   !empty($_POST['url'])) {
  // ファイルの存在をチェック
  $upload_dir = wp_upload_dir();
  // var_dump($upload_dir);
  $full_path = $upload_dir['basedir']."/".$_POST['image_path'];

  if (file_exists($full_path)) {
    $serialize = serialize($_POST);
    // ↓ これでoptionsテーブルに入る、無ければ追加になる
    $res = update_option('modal_scroll_geoge', $serialize);

    if($res) {
      $info = "追加しました";
    } else {
      $info = "追加できませんでした";
    }
  } else {
    $info = "$full_path 画像ファイルが存在しません";
  }
}
?>

<!--他のメニュー画面に影響を与えないため-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<h2 class="text-center">モーダル画像設定</h2>

<p class="fs-5"> <?= $info ?> </p>

<form action="" method="post">
  <div class="container w-50">

    <div class="input-group ">
      <div class="input-group-text">/wp-content/uploads/</div>
      <input type="text" class="form-control" placeholder="2024/12/679.jpg" name="image_path" required>
    </div>

    <div class="input-group mt-5 px-5">
      <label>カテゴリ選択(複数可)</label>
      <select class="form-select mx-5" multiple aria-label="Default select example" name="cat_ID[]" required>
        <?php
      $categories = get_categories();
      foreach( $categories as $category ) {
        echo "<option value='$category->cat_ID'>$category->name</option>";
      }
    ?>
      </select>
    </div>


    <div class="input-group mt-5 px-5">
      <label>表示位置(TOPからのpx指定)</label>
      <input type="text" class="form-control mx-5" value="600" name="top"> px
    </div>


    <div class="input-group mt-5">
      <div class="input-group-text">URL</div>
      <input type="url" class="form-control" placeholder="https://abcd.efg?p=123" name="url">
    </div>

    <button type="submit" class="btn btn-primary mt-5">Submit</button>
  </div>
</form>